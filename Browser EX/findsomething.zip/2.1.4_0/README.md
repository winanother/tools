# FindSomething
FindSomething，基于浏览器插件的被动式信息提取工具  
首发于陌陌安全 https://security.immomo.com/blog/145
## chrome插件
1. 直接访问 https://chrome.google.com/webstore/detail/findsomething/kfhniponecokdefffkpagipffdefeldb  
2. 或使用chrome开发者模式加载源码。
## firefox插件
1. 直接访问 https://addons.mozilla.org/zh-CN/firefox/addon/findsomething/
2. 或切换到firefox分支，使用“调试附加组件”加载。  

欢迎一起交流，微信搜索canxiao_xiao